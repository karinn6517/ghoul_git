package karin.slot.ghoul.ghoul;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GhoulApplicationTests {

	@Test
	void contextLoads() {
	}

}
