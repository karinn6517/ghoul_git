package karin.slot.ghoul.ghoul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GhoulApplication {

	public static void main(String[] args) {
		SpringApplication.run(GhoulApplication.class, args);
	}

}
